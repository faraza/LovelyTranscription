import { LucideIcon } from "lucide-react";
import { ParentingDimension } from "../types/parenting";

interface DimensionCardProps {
  dimension: ParentingDimension;
  score: number;
  onOpenModal: () => void;
}

export default function DimensionCard({ dimension, score, onOpenModal }: DimensionCardProps) {
  const IconComp = dimension.icon;
  
  return (
    <div className={`bg-gradient-to-br ${dimension.background} rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all flex flex-col justify-between`}>
      <div className="flex items-center mb-4">
        {IconComp && <IconComp className="text-gray-700 w-6 h-6 mr-2" />}
        <h3 className="text-lg font-semibold text-gray-800">
          {dimension.dimension}
        </h3>
      </div>

      <div className={`text-center mt-4 text-5xl font-extrabold ${dimension.color}`}>
        {score}
      </div>

      <p className="mt-4 text-base text-gray-800 text-center font-medium leading-snug">
        {dimension.subMetrics[0].reasonsHigh[0] || dimension.subMetrics[0].reasonsLow[0] ||
          "Detailed behavior analysis available."}
      </p>

      <button
        onClick={onOpenModal}
        className="mt-4 bg-white text-gray-800 text-sm px-4 py-2 rounded-full self-center hover:bg-gray-100 border border-gray-300"
      >
        View Details
      </button>
    </div>
  );
} 