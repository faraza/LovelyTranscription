import { X } from "lucide-react";
import { ParentingDimension } from "../types/parenting";

interface DimensionModalProps {
  dimension: ParentingDimension;
  onClose: () => void;
}

export default function DimensionModal({ dimension, onClose }: DimensionModalProps) {
  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-60 flex items-center justify-center px-4">
      <div className="bg-white p-6 rounded-2xl max-w-xl w-full text-gray-800 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold mb-4 text-center">
          {dimension.dimension}
        </h2>
        {dimension.subMetrics.map((sub, idx) => (
          <div key={idx} className="mb-4">
            <h3 className="text-md font-semibold mb-1">
              {sub.name} — {sub.score}/100
            </h3>
            {sub.reasonsHigh.length > 0 && (
              <div className="text-green-600 text-sm mb-1">
                Strengths: {sub.reasonsHigh.join(", ")}
              </div>
            )}
            {sub.reasonsLow.length > 0 && (
              <div className="text-red-600 text-sm">
                Areas to Improve: {sub.reasonsLow.join(", ")}
              </div>
            )}
            {sub.snippetExamples?.length > 0 && (
              <div className="mt-2 space-y-2">
                {sub.snippetExamples.map((snippet, sidx) => (
                  <div key={sidx} className="bg-gray-100 p-3 rounded text-sm">
                    <p className="mb-1 text-gray-700">{snippet.text}</p>
                    {snippet.audio && (
                      <audio controls className="w-full">
                        <source src={snippet.audio} type="audio/mpeg" />
                      </audio>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
} 