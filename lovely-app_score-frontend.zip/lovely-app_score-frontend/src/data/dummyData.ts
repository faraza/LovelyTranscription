import { Heart, Smile, Shield, Sun, ThumbsUp } from "lucide-react";
import { ParentingDimension } from "../types/parenting";

export const dummyData: ParentingDimension[] = [
  {
    dimension: "Responsive & Engaged Parenting",
    score: 92,
    icon: Heart,
    color: "text-gray-800",
    background: "from-green-100 to-lime-200",
    subMetrics: [
      {
        name: "Responsiveness & Attentiveness",
        score: 92,
        snippetExamples: [
          {
            text: "You: 'I love how you're describing everything in detail. Keep going!'",
            audio: "https://example.com/audio-snippet1.mp3",
          },
        ],
        reasonsHigh: [
          "You did a great job asking open-ended questions that encouraged dialogue."
        ],
        reasonsLow: [],
      },
    ],
  },
  {
    dimension: "Emotional Support & Connection",
    score: 78,
    icon: Smile,
    color: "text-gray-800",
    background: "from-orange-100 to-amber-200",
    subMetrics: [
      {
        name: "Empathetic Responses",
        score: 75,
        snippetExamples: [],
        reasonsHigh: [
          "You showed understanding by validating your child's feelings."
        ],
        reasonsLow: [
          "You sometimes dismissed your child's concerns instead of exploring them."
        ],
      },
    ],
  },
  {
    dimension: "Guidance with Boundaries & Respect",
    score: 91,
    icon: Shield,
    color: "text-gray-800",
    background: "from-sky-100 to-cyan-200",
    subMetrics: [
      {
        name: "Clear Boundaries",
        score: 92,
        snippetExamples: [],
        reasonsHigh: ["You clearly explained rules in a respectful tone."],
        reasonsLow: ["You were occasionally inconsistent in follow-through."],
      },
    ],
  },
  {
    dimension: "Encouraging Curiosity & Learning",
    score: 59,
    icon: Sun,
    color: "text-gray-800",
    background: "from-rose-100 to-red-200",
    subMetrics: [
      {
        name: "Open-Ended Questions",
        score: 59,
        snippetExamples: [],
        reasonsHigh: [],
        reasonsLow: [
          "You missed opportunities to support curiosity through open-ended questions."
        ],
      },
    ],
  },
  {
    dimension: "Unconditional Love & Positive Communication",
    score: 87,
    icon: ThumbsUp,
    color: "text-gray-800",
    background: "from-purple-100 to-pink-200",
    subMetrics: [
      {
        name: "Loving Reassurance",
        score: 86,
        snippetExamples: [],
        reasonsHigh: ["You offered affirming and loving words consistently."],
        reasonsLow: [],
      },
    ],
  },
]; 