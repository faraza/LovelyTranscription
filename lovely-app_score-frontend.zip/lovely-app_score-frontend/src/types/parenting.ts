import { LucideIcon } from "lucide-react";

export interface SnippetExample {
  text: string;
  audio?: string;
}

export interface SubMetric {
  name: string;
  score: number;
  snippetExamples: SnippetExample[];
  reasonsHigh: string[];
  reasonsLow: string[];
}

export interface ParentingDimension {
  dimension: string;
  score: number;
  icon: LucideIcon;
  color: string;
  background: string;
  subMetrics: SubMetric[];
} 