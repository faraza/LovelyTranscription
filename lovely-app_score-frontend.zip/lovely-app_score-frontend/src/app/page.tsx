"use client";

import { useState, useEffect } from "react";
import { dummyData } from "../data/dummyData";
import DimensionCard from "../components/DimensionCard";
import DimensionModal from "../components/DimensionModal";

export default function Home() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [animatedScores, setAnimatedScores] = useState<number[]>([]);

  useEffect(() => {
    const steps = 20;
    const duration = 500;
    const interval = duration / steps;
    let count = 0;
    const increments = dummyData.map((dim) => dim.score / steps);
    let current = dummyData.map(() => 0);

    const timer = setInterval(() => {
      count++;
      current = current.map((val, i) => Math.min(dummyData[i].score, val + increments[i]));
      setAnimatedScores([...current]);
      if (count >= steps) clearInterval(timer);
    }, interval);

    return () => clearInterval(timer);
  }, []);

  const openModal = (index: number) => {
    setExpandedIndex(index);
  };

  const closeModal = () => {
    setExpandedIndex(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-100 text-gray-800">
      <div className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 py-16 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-3">Your Parenting Health Dashboard</h1>
            <p className="text-lg text-gray-700 text-opacity-90 mb-6">
              Track and improve your most meaningful relationship metrics.
            </p>
          </div>
        </div>
      </div>

      {/* Three Cards Section */}
      <div className="max-w-6xl mx-auto px-4 mb-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* CARD 1: Positive Encouragement */}
          <div className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all flex flex-col">
            <div className="mb-4 flex items-center">
              <svg
                className="w-8 h-8 mr-2 text-green-500"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path 
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3 10h1m6 0h1m2 0h1m2 0h1m2 0h1M3 6h18M3 14h18M3 18h18"
                />
              </svg>
              <h2 className="text-xl font-bold leading-tight">Parenting Win!</h2>
            </div>
            <p className="text-base text-gray-700 mb-4">
              You did a great job helping your child label their emotions.
              For example, when you told Kio, "Is that making you sad?" in response to his toy breaking based on his reaction,
              it helped him pinpoint his feelings.
            </p>
            <p className="text-base text-gray-700 mt-auto">
              Continue your parenting skills journey by practicing
              responsiveness with your child during your 5 minutes of playtime (
              <a href="#" className="underline text-blue-600 hover:text-blue-800">
                how
              </a>
              ).
            </p>
          </div>

          {/* CARD 2: Skills Level */}
          <div className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all flex flex-col">
            <div className="mb-4 flex items-center">
              <svg
                className="w-8 h-8 mr-2 text-indigo-500"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 8c1.657 0 3.157.67 4.243 1.757A6 6 0 0118 12h2a4 4 0 00-4-4h-.757A6 6 0 0112 6a6 6 0 00-4.243 1.757A6 6 0 006 12h2a4 4 0 014-4z"
                />
              </svg>
              <h2 className="text-xl font-bold leading-tight">Your Current Skills Level</h2>
            </div>
            <p className="text-sm text-gray-700 mb-4">
              You are currently at a{" "}
              <span className="font-semibold text-green-600">Typical</span> level.
            </p>

            {/* Step Progress Tracker */}
            <div className="flex justify-between items-center text-xs text-gray-600 mb-3">
              <span>Beginner</span>
              <span>Typical</span>
              <span>Intermediate</span>
              <span>Proficient</span>
              <span>Expert</span>
            </div>

            {/* The stepper bar itself */}
            <div className="flex items-center justify-between relative h-2 bg-gray-200 rounded-full mb-8">
              {/* Background dots */}
              {[0, 1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className="w-2 h-2 rounded-full bg-gray-400 z-0"
                  style={{ transform: "translateX(-50%)" }}
                />
              ))}
              
              {/* Current level range indicator */}
              <div 
                className="absolute h-4 bg-green-500 rounded-full z-10"
                style={{ 
                  left: "15%", 
                  right: "65%",
                  top: "50%",
                  transform: "translateY(-50%)"
                }}
              />
              
              <div
                className="absolute top-6 left-1/4 transform -translate-x-1/2 text-xs text-green-700 font-semibold"
              >
                You are here
              </div>
            </div>
          </div>

          {/* CARD 3: Practice Plan */}
          <div className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all flex flex-col">
            <div className="mb-4 flex items-center">
              <svg
                className="w-8 h-8 mr-2 text-pink-500"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 6v6l4 2"
                />
              </svg>
              <h2 className="text-xl font-bold leading-tight">Practice Plan This Week</h2>
            </div>
            <p className="text-base text-gray-700 mt-auto">
              5 minutes of play with each child, every day. Set a reminder and make it
              a playful moment of connection.
            </p>
          </div>
        </div>
      </div>

      {/* At A Glance Section */}
      <div className="px-4 py-8 max-w-6xl mx-auto relative">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-semibold">At A Glance</h2>
          <p className="text-sm text-gray-500 mt-2">
            Explore how you did in each of the core parenting dimensions.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {dummyData.map((dim, i) => (
            <DimensionCard
              key={i}
              dimension={dim}
              score={Math.round(animatedScores[i] || 0)}
              onOpenModal={() => openModal(i)}
            />
          ))}
        </div>
      </div>

      {expandedIndex !== null && (
        <DimensionModal
          dimension={dummyData[expandedIndex]}
          onClose={closeModal}
        />
      )}
    </div>
  );
}
